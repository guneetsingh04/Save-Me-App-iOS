//
//  EditVC.swift
//  SafetyApp
//
//  Created by Guneet Singh on 2018-07-25.
//  Copyright © 2018 Guneet Singh. All rights reserved.
//

import Foundation
import UIKit
import CoreData
import Firebase
import FirebaseDatabase

class EditVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate
{
    var currentId : String? = nil
    var strURL : String? = nil
    
    @IBOutlet weak var imgPick3: UIImageView!
    
    @IBOutlet weak var changePass: UITextField!
    @IBAction func chooseImg(_ sender: Any) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        
        let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a Source", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action: UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera)
            {
                imagePickerController.sourceType = .camera
                self.present(imagePickerController, animated: true, completion: nil)
            }
            else
            {
                print("Camera not available")
            }
        }))
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action: UIAlertAction) in
            imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion: nil)
        }))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action: UIAlertAction) in }))
        
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    @IBOutlet weak var name: UITextField!

    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBAction func registerButton(_ sender: Any) {
        if (phone.text?.characters.count)! < 10
        {
            let alert = UIAlertController(title: "Invalid Phone Number", message: "Please Enter a Valid Phone number", preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok thanks", style: .default, handler: nil)
            alert.addAction(action)
            present(alert,animated: true, completion: nil)
            return
        }
        guard let newemail = email.text, let newname = name.text, let newphone = phone.text else {
            print("form is not valid")
           
            return
        }
        
     
     let storageRef = Storage.storage().reference().child("profile_images").child("\(currentId!).png")
        
        if let uploadData = UIImagePNGRepresentation(imgPick3.image!){
            
            storageRef.putData(uploadData, metadata: nil) { (metadata, error) in
              /*  if error != nil {
                    print(error)
                    return
                }*/
                
                storageRef.downloadURL(completion: { (url, error) in
                    if let urlText = url?.absoluteString {
                        
                        self.strURL = urlText
                        //print(self.strURL)
                        let value = ["name": newname, "email": newemail, "contact": newphone, "profileImageUrl": self.strURL!] as [String:AnyObject]
                        self.handleRegisterWithUID(uid: self.currentId!, values: value)
                        //completion(strURL)
                    }
                })
                
                
                //print(metadata)
            }
        }
      
   
    }
    
    private func handleRegisterWithUID(uid:String, values: [String: AnyObject]){
        let ref =  Database.database().reference(fromURL: "https://saveme-6980a.firebaseio.com/")
        let profileRefrence = ref.child("Users").child(currentId!)
        //let values = ["name": newname, "email": newemail, "contact": newphone, "profileImageUrl": strURL!]
        
        profileRefrence.updateChildValues(values, withCompletionBlock: { (err, ref) in
            if err != nil {
                
                print(err)
                return
            }
            print("User Updated")
            let vc = self.storyboard!.instantiateViewController(withIdentifier: "viewcontroller") as! UITabBarController
            //  self.tabBarController?.present(vc, animated: true, completion: nil)
            self.present(vc, animated: true, completion: nil)        })
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.name.delegate = self
        self.phone.delegate = self
        imgPick3.layer.cornerRadius = imgPick3.frame.size.width/2
        imgPick3.clipsToBounds = true
        
        checkLogin()
       
    }
    
    func checkLogin(){
        
        if Auth.auth().currentUser?.uid == nil {
            
            performSelector(inBackground: #selector(handleLogout), with: nil)
        } else {
            let uid = Auth.auth().currentUser?.uid
            print(uid!)
            Database.database().reference(fromURL: "https://saveme-6980a.firebaseio.com/").child("Users").child(uid!).observe(.value) { (snapshot) in
                if let dictionary = snapshot.value as? [String: AnyObject]{
                    self.name.text = dictionary["name"] as? String
                    self.phone.text = dictionary["contact"] as? String
                    self.email.text = dictionary["email"] as? String
                    self.currentId = uid
                    if let profileImageUrl = dictionary["profileImageUrl"] as? String {
                        let url = URL(string: profileImageUrl)
                 
                        URLSession.shared.dataTask(with: url!) { (data, response, error) in
                            if error != nil{
                                print(error)
                                return
                            }
                          //  DispatchQueue.main.async(execute: DispatchQueue.main())
                            DispatchQueue.main.async {
                                self.imgPick3?.image = UIImage(data: data!)
                            }
                            
                        }.resume()
                    }
            }
            
            }
        }
    }
    
    @IBAction func changePassword(_ sender: Any) {
        var user = Auth.auth().currentUser
        var newPassword = changePass.text
        
        user?.updatePassword(to: newPassword!, completion: { (error) in
            //print("Password Updated")
            if error != nil {
                print(error)
                return
            }
            print("Password Updated")
            let vc = self.storyboard!.instantiateViewController(withIdentifier: "viewcontroller") as! UITabBarController
            //  self.tabBarController?.present(vc, animated: true, completion: nil)
            self.present(vc, animated: true, completion: nil)
            
        })
     
    }
    
    
    @objc func handleLogout(){
        do{
            try Auth.auth().signOut()
        } catch let logoutErr {
            print(logoutErr)
        }
        let vc = self.storyboard!.instantiateViewController(withIdentifier: "firstviewcontroller") as! UIViewController
        //  self.tabBarController?.present(vc, animated: true, completion: nil)
        self.present(vc, animated: true, completion: nil)

    }
  
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String: Any]) {
        
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        imgPick3.image = image
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        name.resignFirstResponder()
        phone.resignFirstResponder()
        return true
    }
}
